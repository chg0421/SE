/*globals describe beforeEach Controller it expect aProduct Company SalesPerson Product*/
describe("Question Four and Question Five", function () {
    'use strict';
    describe("Product", function () {
        var product;
        beforeEach(function () {
            product = new Product();
        });

        it("should have an .id property", function () {
            expect(product.hasOwnProperty('id')).toBeTruthy();
        });

        it("should have a .name property", function () {
            expect(product.hasOwnProperty('name')).toBeTruthy();
        });

        it("should have a .price property", function () {
            expect(product.hasOwnProperty('price')).toBeTruthy();
        });

        it("should have a .quantityOnHand property", function () {
            expect(product.hasOwnProperty('quantityOnHand')).toBeTruthy();
        });

        it("should have a .minimumQuantity property", function () {
            expect(product.hasOwnProperty('minimumQuantity')).toBeTruthy();
        });

        it("should have a .myCompany reference", function () {
            expect(product.hasOwnProperty('myCompany')).toBeTruthy();
        });
    });

    describe("write a Company.addProduct function to add the Products", function () {
        var theCompany;
        beforeEach(function () {
            var theController;
            theController = new Controller();
            theCompany = theController.setup();
        });

        it("should have added 4 Products", function () {
            expect(theCompany.allMyProducts.length).toBe(4);
        });

        it("should correctly set product details", function () {

    /*
      ID     Name      Price    QuantityOnHand  MinimumQuantity
      NU     Nut       11.95        100               200
      SC     Screw     15.75        150               100
      WA     Washer    12.50         80                50
      BO     Bolt      20.00         50               100
    */
            var aProduct;
            aProduct = theCompany.sortProducts();
            //BO     Bolt      20.00         50               100
            aProduct = theCompany.allMyProducts[0];
            expect(aProduct.myCompany).toEqual(theCompany);
            expect(aProduct.id).toBe('BO');
            expect(aProduct.name).toBe('Bolt');
            expect(aProduct.price).toBe(20.00);
            expect(aProduct.quantityOnHand).toBe(50);
            expect(aProduct.minimumQuantity).toBe(100);

            //NU     Nut       11.95        100               200
            aProduct = theCompany.allMyProducts[1];
            expect(aProduct.myCompany).toEqual(theCompany);
            expect(aProduct.id).toBe('NU');
            expect(aProduct.name).toBe('Nut');
            expect(aProduct.price).toBe(11.95);
            expect(aProduct.quantityOnHand).toBe(100);
            expect(aProduct.minimumQuantity).toBe(200);

            //SC     Screw     15.75        150               100
            aProduct = theCompany.allMyProducts[2];
            expect(aProduct.myCompany).toEqual(theCompany);
            expect(aProduct.id).toBe('SC');
            expect(aProduct.name).toBe('Screw');
            expect(aProduct.price).toBe(15.75);
            expect(aProduct.quantityOnHand).toBe(150);
            expect(aProduct.minimumQuantity).toBe(100);

            //WA     Washer    12.50         80                50
            aProduct = theCompany.allMyProducts[3];
            expect(aProduct.myCompany).toEqual(theCompany);
            expect(aProduct.id).toBe('WA');
            expect(aProduct.name).toBe('Washer');
            expect(aProduct.price).toBe(12.50);
            expect(aProduct.quantityOnHand).toBe(80);
            expect(aProduct.minimumQuantity).toBe(50);
        });
    });
});