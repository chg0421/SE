/*globals describe beforeEach Controller it expect Company SalesPerson*/
describe("Question Three", function () {
    'use strict';
    describe("Company.getAllSalesPeople  function", function () {
        var theCompany;
        beforeEach(function () {
            var theController;
            theController = new Controller();
            theCompany = theController.setup();
        });

        it("should return a string", function () {
            expect(typeof theCompany.getAllSalesPeople()).toBe('string');
        });

        it("should NOT be hard coded", function () {
            theCompany = new Company();
            expect(theCompany.getAllSalesPeople()).toBe('');
        });

        it("should return correctly formatted data in the right order", function () {
            expect(theCompany.getAllSalesPeople()).toBe('13 - Anderton, Winston.\n11 - Brash, Helen.\n12 - Clarke, Don.\n14 - Peters, Jim.\n');
        });
    });
});