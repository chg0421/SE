/*globals describe beforeEach Controller it expect Company SalesPerson Product*/
describe("Question Two", function () {
    'use strict';
    describe("adding the four SalesPersons", function () {
        var theCompany;
        beforeEach(function () {
            var theController = new Controller();
            theCompany = theController.setup();
        });

        it("should have added 4 SalesPersons", function () {
            expect(theCompany.allMySalesPersons.length).toBe(4);
        });

        it("should have correctly set details for each SalesPerson", function () {
            var aSalesPerson;
            aSalesPerson = theCompany.sortSalesPersons();

            aSalesPerson = theCompany.allMySalesPersons[0];
            expect(aSalesPerson).toBeDefined();
            expect(aSalesPerson.id).toBe('13');
            expect(aSalesPerson.firstName).toBe('Winston');
            expect(aSalesPerson.lastName).toBe('Anderton');
            expect(aSalesPerson.salary).toBe(42.000);
            expect(aSalesPerson.yearCommenced).toBe(2002);

            aSalesPerson = theCompany.allMySalesPersons[1];
            expect(aSalesPerson).toBeDefined();
            expect(aSalesPerson.id).toBe('11');
            expect(aSalesPerson.firstName).toBe('Helen');
            expect(aSalesPerson.lastName).toBe('Brash');
            expect(aSalesPerson.salary).toBe(47.000);
            expect(aSalesPerson.yearCommenced).toBe(1999);

            aSalesPerson = theCompany.allMySalesPersons[2];
            expect(aSalesPerson).toBeDefined();
            expect(aSalesPerson.id).toBe('12');
            expect(aSalesPerson.firstName).toBe('Don');
            expect(aSalesPerson.lastName).toBe('Clarke');
            expect(aSalesPerson.salary).toBe(37.000);
            expect(aSalesPerson.yearCommenced).toBe(2003);

            aSalesPerson = theCompany.allMySalesPersons[3];
            expect(aSalesPerson).toBeDefined();
            expect(aSalesPerson.id).toBe('14');
            expect(aSalesPerson.firstName).toBe('Jim');
            expect(aSalesPerson.lastName).toBe('Peters');
            expect(aSalesPerson.salary).toBe(39.000);
            expect(aSalesPerson.yearCommenced).toBe(1998);
        });
    });
});