/*globals describe beforeEach Controller it expect aProduct Company SalesPerson Product*/
describe("Question Six", function () {
    'use strict';
    describe("Product.moreNeeded function", function () {
        var aProduct;
        beforeEach(function () {
            aProduct = new Product();
        });

        it("should exist", function () {
            expect(aProduct.moreNeeded()).toBeDefined();
        });

        it("should return a boolean", function () {
            expect(typeof aProduct.moreNeeded()).toBe('boolean');
        });

        it("should return true if quantity on hand for a product is less than its minimum quantity.", function () {
            aProduct = new Product(null, null, null, 10, 50);
            expect(aProduct.moreNeeded()).toBe(true);
        });

        it("should return false if quantity on hand for a product is equal to its minimum quantity.", function () {
            aProduct = new Product(null, null, null, 50, 50);
            expect(aProduct.moreNeeded()).toBe(false);
        });

        it("should return false if quantity on hand for a product is more than its minimum quantity.", function () {
            aProduct = new Product(null, null, null, 1000, 50);
            expect(aProduct.moreNeeded()).toBe(false);
        });
    });
});