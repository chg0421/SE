/*globals describe beforeEach it expect Company SalesPerson Product*/
describe("Basic Check For Original Source Code", function () {
    'use strict';
    describe("Company", function () {
        var theCompany;
        beforeEach(function () {
            theCompany = new Company();
        });

        describe("the allMySalesPersons property", function () {
            it("should have an .allMySalesPersons property", function () {
                expect(theCompany.hasOwnProperty('allMySalesPersons')).toBeTruthy();
            });
            it("should reference an array", function () {
                expect(Array.isArray(theCompany.allMySalesPersons)).toBeTruthy();
            });
        });

        it("should have an .addSalesPerson function", function () {
            expect(typeof theCompany.addSalesPerson).toBe('function');
        });

        it("should have a .sortSalesPersons function", function () {
            expect(typeof theCompany.sortSalesPersons).toBe('function');
        });

        it("should have a .sortProducts function", function () {
            expect(typeof theCompany.sortProducts).toBe('function');
        });
    });

    describe("SalesPerson", function () {
        var salesPerson;
        beforeEach(function () {
            salesPerson = new SalesPerson();
        });

        it("should have an .id property", function () {
            expect(salesPerson.hasOwnProperty('id')).toBeTruthy();
        });

        it("should have a .firstName property", function () {
            expect(salesPerson.hasOwnProperty('firstName')).toBeTruthy();
        });

        it("should have a .lastName property", function () {
            expect(salesPerson.hasOwnProperty('lastName')).toBeTruthy();
        });

        it("should have a .salary property", function () {
            expect(salesPerson.hasOwnProperty('salary')).toBeTruthy();
        });

        it("should have a .yearCommenced property", function () {
            expect(salesPerson.hasOwnProperty('yearCommenced')).toBeTruthy();
        });

        it("should have a .myCompany reference", function () {
            expect(salesPerson.hasOwnProperty('myCompany')).toBeTruthy();
        });
    });
});