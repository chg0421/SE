/*globals describe beforeEach Controller it expect Company SalesPerson Product*/
describe("Question One", function () {
    'use strict';
    describe("Draw a class diagram", function () {});
});