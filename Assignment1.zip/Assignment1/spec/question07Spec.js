/*globals describe beforeEach Controller it expect Company SalesPerson Product*/
describe("Question Seven", function () {
    'use strict';
    describe("Company.getProductsToOrder function", function () {
        var theCompany;
        beforeEach(
            function () {
                var theController;
                theController = new Controller();
                theCompany = theController.setup();
            }
        );

        it("should return a string", function () {
            expect(typeof theCompany.getProductsToOrder()).toBe('string');
        });

        it("should NOT be hard coded", function () {
            theCompany = new Company();
            expect(theCompany.getProductsToOrder()).toBe('');
        });

        it("should correctly report details of Product if the quantity on hand for a product is less than its minimum quantity", function () {
            expect(theCompany.getProductsToOrder()).toBe('BO - Bolt\nNU - Nut\n');
        });
    });
});