Hi Amit,
I have added the modified class diagram.
Assignment1\Templates\ClassDiagram.png
Thank you