/* jshint undef: true, unused: true, esversion: 6, asi: true */
class SalesPerson {
    constructor(newId, newFirstName, newLastName, newSalary, newYearCommenced, theCompany) {
        this.id = newId
        this.firstName = newFirstName
        this.lastName = newLastName
        this.salary = newSalary
        this.yearCommenced = newYearCommenced
        this.myCompany = theCompany
    }
    toString() {
        let result
        result = `${this.id} - ${this.lastName}, ${this.firstName}.<br>`
        return result
    }
}
