/* jshint undef: true, unused: true, esversion: 6, asi: true */
class Controller {
    static setup() {
        let theCompany
        theCompany = new Company()
        //theCompany.addSalesPerson(newId, newFirstName, newLastName, newSalary, newYearCommenced, theCompany);
        theCompany.addSalesPerson('13', 'Winston', 'Anderton', 42.000, 2002)
        theCompany.addSalesPerson('11', 'Helen', 'Brash', 47.000, 1999)
        theCompany.addSalesPerson('12', 'Don', 'Clarke', 37.000, 2003)
        theCompany.addSalesPerson('14', 'Jim', 'Peters', 39.000, 1998)
        // ADD CODE HERE TO CREATE THE SALESPERSONS
        //theCompany.addProduct(newId, newName, newPrice, newMinimumQuantity, newQuantityOnHand, theCompany)
        theCompany.addProduct('BO', 'Bolt', 20.00, 100, 50)
        theCompany.addProduct('NU', 'Nut', 11.95, 200, 100)
        theCompany.addProduct('SC', 'Screw', 15.75, 100, 150)
        theCompany.addProduct('WA', 'Washer', 12.50, 50, 80)
        //ADD CODE HERE TO CREATE THE PRODUCTS
        return theCompany
    }
}
