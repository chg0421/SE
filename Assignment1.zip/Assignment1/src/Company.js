/* jshint undef: true, unused: true, esversion: 6, asi: true */
class Company {
    constructor() {
        this.allMyProducts = []
        this.allMySalesPersons = []
    }
    getAllSalesPeople() {
        this.sortSalesPersons()
        let out = ''
        this.allMySalesPersons.forEach((aSalesPerson) => {
            out = `${out}${aSalesPerson}\n`
        })
        return out
    }
    addSalesPerson(newId, newFirstName, newLastName, newSalary, newYearCommenced) {

        let newSalesPerson = new SalesPerson(newId, newFirstName, newLastName, newSalary, newYearCommenced, this)
        this.allMySalesPersons.push(newSalesPerson)
    }
    addProduct(newId, newName, newPrice, newMinimumQuantity, newQuantityOnHand) {

        let newProduct = new Product(newId, newName, newPrice, newMinimumQuantity, newQuantityOnHand, this)
        this.allMyProducts.push(newProduct)
    }
    getProductsToOrder() {
        this.sortProducts()
        let out = ''
        this.allMyProducts.forEach((aProduct) => {
            if (!aProduct.moreNeeded()) {
                out = `${out}${aProduct}\n`
            }
        })
        return out
    }
    sortSalesPersons() {
        this.allMySalesPersons.sort(function (a, b) {
            return a.lastName > b.lastName
        })
    }
    sortProducts() {
        this.allMyProducts.sort(function (a, b) {
            return a.id > b.id
        })
    }
}
